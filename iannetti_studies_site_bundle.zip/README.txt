
Iannetti Studies – Static Site

Files:
- index.html       (homepage)
- styles.css       (site styles)
- /assets/hero.jpg (placeholder banner; replace with your wood background image)
- sitemap.xml      (placeholder; replace with your real sitemap.xml if you have one)

GitHub Pages quick deploy:
1) Go to https://github.com/iannettistudies/iannettistudies.github.io
2) Click 'Add file' > 'Upload files' and upload everything in this bundle to the repo root.
3) Commit to main.
4) Visit https://iannettistudies.github.io/ to verify.
5) In Namecheap DNS, point your domain (CNAME) at iannettistudies.github.io and add a CNAME file if you want the custom domain.

Buttons/Links are already wired for:
- Google Scholar
- Zenodo community
- Soap by Ashley group
